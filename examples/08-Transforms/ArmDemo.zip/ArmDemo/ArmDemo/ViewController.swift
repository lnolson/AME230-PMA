//
//  ViewController.swift
//  
//  An arm with 3 joints - a movement hierarchy.
//  Uses pushState, popState, translate, rotate to create movement.
//
//  Press any key to toggle thru the joints.
//  Drag mouse left-right to rotate current joint.

import Cocoa
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        
        view.window?.title = "Arm Demo"
        makeView(width: 1200.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    // Click and drag the mouse to rotate the current joint.
    override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
        let dx = tin.mouseX - tin.pmouseX
        scene.moveActiveJoint(dx: dx)
    }
    
    // Press any key to switch to the next joint.
    override func keyUp(with event: NSEvent) {
        super.keyUp(with: event)
        scene.changeActiveJoint()
    }

}


// An enumeration for the different options for "active joint"
enum ActiveJoint {
    case Shoulder
    case Elbow
    case Wrist
}


class Scene: TScene {
    // scene properties here
    let jointRadius = 20.0
    let upperLength = 160.0
    let lowerLength = 120.0
    let handLength = 80.0
    var shoulderAngle = 0.0
    var elbowAngle = 0.0
    var wristAngle = 0.0
    var state = ActiveJoint.Shoulder
    var font = TFont(fontName: "Helvetica Neue Light", ofSize: 14.0)
    
    
    override func setup() {
        font.horizontalAlignment = .left
    }
    
    override func update() {
        background(red: 0.5, green: 0.5, blue: 0.5)
        
        drawArm()
        
        fillColor(gray: 1.0)
        text(message: "Press space bar to cycle selected joint. Drag left-right to rotate joint.", font: font, x: 10, y: 10)
    }
    
    
    func drawArm() {
        // Arm hierarchy
        
        // shoulder
        pushState()
        translate(dx: 300.0, dy: 300.0)
        rotate(by: shoulderAngle)
        fillColor(gray: 1)
        if state == .Shoulder {
            fillColor(red: 0.1, green: 0.9, blue: 0.1, alpha: 1)
        }
        // Shoulder joint
        drawJoint(radius: jointRadius)
        
        drawUpperArm()
        
        popState()  // pop shoulder
    }
    
    
    func drawUpperArm() {
        // upperArm
        drawSegment(length: upperLength, radius: jointRadius)
        
        // elbow
        pushState()
        translate(dx: upperLength + jointRadius, dy: 0)
        rotate(by: elbowAngle)
        fillColor(gray: 1)
        if state == .Elbow {
            fillColor(red: 0.1, green: 0.9, blue: 0.1, alpha: 1)
        }
        // Elbow joint
        drawJoint(radius: jointRadius)
        
        drawLowerArm()
        
        popState()  // pop elbow
    }
    
    
    func drawLowerArm() {
        // lowerarm
        drawSegment(length: lowerLength, radius: jointRadius)
        
        // wrist
        pushState()
        translate(dx: lowerLength + jointRadius, dy: 0)
        rotate(by: wristAngle)
        fillColor(gray: 1)
        if state == .Wrist {
            fillColor(red: 0.1, green: 0.9, blue: 0.1, alpha: 1)
        }
        // Wrist joint
        drawJoint(radius: jointRadius)
        
        // hand
        drawSegment(length: handLength, radius: jointRadius)
        
        popState()  // pop wrist
    }

    
    func drawJoint(radius: Double) {
        let w = radius * 2
        ellipse(centerX: 0, centerY: 0, width: w, height: w)
        line(x1: 0, y1: -radius, x2: 0, y2: radius)
        line(x1: -radius, y1: 0, x2: radius, y2: 0)
    }
    
    
    func drawSegment(length: Double, radius: Double) {
        translate(dx: radius, dy: 0)
        fillColor(gray: 1)
        rect(x: 0.0, y: -radius, width: length, height: radius * 2)
    }
    
    
    func moveActiveJoint(dx: Double) {
        let movementScale = 0.05
        switch state {
        case .Shoulder:
            shoulderAngle += (dx * movementScale)
        case .Elbow:
            elbowAngle += (dx * movementScale)
        case .Wrist:
            wristAngle += (dx * movementScale)
        }
    }
    
    
    func changeActiveJoint() {
        switch state {
        case .Shoulder:
            state = .Elbow
        case .Elbow:
            state = .Wrist
        case .Wrist:
            state = .Shoulder
        }
    }
    
    
}

