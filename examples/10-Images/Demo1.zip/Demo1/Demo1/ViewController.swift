//
//  ViewController.swift
//
//  Demonstrates how to draw using an image.
//  Add two image files to the project.
//  Use the image files to create TImage objects.
//  Draw using image function and the TImage objects.


import Cocoa
import Tin


class ViewController: TController {
    var scene: Scene!
    
    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var bird: TImage!
    var sparky: TImage!
    
    override func setup() {
        bird = TImage(contentsOfFileInBundle: "puffin_medium.jpg")
        sparky = TImage(contentsOfFileInBundle: "Sparky.png")
    }
    
    override func update() {
        background(gray: 0.5)
        
        let x = tin.midX - (bird.width / 2.0)
        let y = tin.midY - (bird.height / 2.0)
        image(image: bird, x: x, y: y)
        
        image(image: bird, x: 50, y: 50, width: 241, height: 160)
        
        image(image: sparky, x: 400, y: 100)
    }
    
}

