//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Interp"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func keyDown(with event: NSEvent) {
        scene.toggle()
    }

}


class Scene: TScene {
    
    var font1 = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 60.0)

    
    override func setup() {
    }
    
    
    override func update() {
        background(gray: 0.5)
        
        let graphX = 100.0
        let graphY = 100.0
        let graphW = tin.width - 200
        let graphH = tin.height - 200
        strokeColor(gray: 0.4)
        fillDisable()
        rect(x: graphX, y: graphY, width: graphW, height: graphH)
        
        
        
        strokeColor(gray: 0.9)
        
        var x = 0.0
        while x < 1.02 {
            
            print("x = \(x)")
            
            let mapX = remap(value: x, start1: 0, stop1: 1, start2: graphX, stop2: graphX + graphW)
            
            
            let y = easeInOutQuart(value: x, start: 20.0, stop: 80.0)
            
            let mapY = remap(value: y, start1: 20.0, stop1: 80.0, start2: graphY, stop2: graphY + graphH)
            
            ellipse(centerX: mapX, centerY: mapY, width: 5, height: 5)
            
            x += 0.02
        }
        
        view?.stopUpdates()
    }
    
    
    
    func toggle() {
    }
    
}

