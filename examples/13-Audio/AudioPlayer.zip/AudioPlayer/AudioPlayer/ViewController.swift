//
//  ViewController.swift
//  AudioDemo1
//
//

import Cocoa
import AVFoundation
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "AudioPlayer"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func mouseDown(with event: NSEvent) {
        scene.play()
    }

}


// Notice that the Scene class is declared to support the
// AVAudioPlayerDelegate protocol.
class Scene: TScene, AVAudioPlayerDelegate {
    
    var audioPlayer: AVAudioPlayer!
    var font1 = TFont(fontName: "Courier New", ofSize: 32)
    var completePlaybacks = 0
    
    
    override func setup() {
        do {
            // In order to use this custom initializer, you must include the
            // AVAudioPlayer extension found below, in your project.
            //
            // Also, note that this initializer can "throw" an exception, so
            // this line must be wrapped in a do block, with a catch clause.
            audioPlayer = try AVAudioPlayer(contentsOfFileInBundle: "drumloop.wav")
        }
        catch {
            // If the AVAudioPlayer init has an error, it will be caught here.
            fatalError(error.localizedDescription)
        }
        audioPlayer.delegate = self
    }
    
    
    override func update() {
        background(gray: 0.5)
        
        if audioPlayer.isPlaying {
            let currentTime = audioPlayer.currentTime
            let displayString = String(format: "playback: %2.2f", arguments: [currentTime])
            fillColor(gray: 1.0)
            text(message: displayString, font: font1, x: tin.midX, y: tin.midY)
            
            let duration = audioPlayer.duration
            let t = currentTime / duration
            drawTimeline(t: t)
        }
        else {
            fillColor(gray: 1.0)
            text(message: "paused", font: font1, x: tin.midX, y: tin.midY)
            drawTimeline(t: 0)
        }
        
        fillColor(gray: 1.0)
        text(message: "Complete plays: \(completePlaybacks)", font: font1, x: tin.midX, y: 32.0)
    }
    
    
    func drawTimeline(t: Double) {
        let x = 100.0
        let y = tin.midY - 80
        let w = tin.width - 200
        let h = 50.0
        
        // A gray interior box
        strokeDisable()
        fillColor(gray: 0.3)
        rect(x: x, y: y, width: w, height: h)
        
        if t > 0.0 {
            // draw the filled, colored portion
            strokeDisable()
            fillColor(red: 0.1, green: 0.7, blue: 0.1, alpha: 1.0)
            rect(x: x, y: y, width: w * t, height: h)
            
            // draw a line at the current progress
            strokeColor(gray: 1.0)
            lineWidth(3)
            line(x1: x + w * t, y1: y, x2: x + w * t, y2: y + h)
            lineWidth(2)
        }
        // draw the outline shape
        strokeColor(gray: 0.8)
        fillDisable()
        rect(x: x, y: y, width: w, height: h)
    }
    
    
    func play() {
        audioPlayer.play()
    }
    
    
    
    
    
    
    // MARK: - AVAudioPlayerDelegate
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        print("The audio finished playing!")
        completePlaybacks += 1
    }
    
}



extension AVAudioPlayer {
    
    // A small extension that makes it easier to use an audio file
    // that is in the main product bundle.
    public convenience init(contentsOfFileInBundle name: String) throws {
        if let path = Bundle.main.path(forResource: name, ofType: "") {
            let url = URL(fileURLWithPath: path)
            try self.init(contentsOf: url)
        }
        else {
            let error = NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "File does not exist, or isn't readable (\(name))."])
            throw error
        }
    }
    
}
