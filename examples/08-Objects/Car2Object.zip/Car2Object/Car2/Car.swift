//
//  Car.swift
//  Car2
//
//  Created by Loren Olson on 2/19/19.
//  Copyright © 2019 ASU. All rights reserved.
//

import Cocoa
import Tin


class Car {
    // Properties (every instance has its own copy.)
    var x = 200.0
    var y = 100.0
    var size = 80.0
    var velocity = 4.0
    
    
    // move method.
    func move() {
        x = x + velocity
        if x > tin.width {
            x = -size
        }
    }
    
    
    // render method.
    func render() {
        // body
        strokeColor(gray: 0)
        fillColor(gray: 0.8)
        rect(x: x, y: y, width: size, height: size/2.0)
        
        //wheels
        let offset = size / 4.0
        let cx = x + size / 2.0
        let cy = y + size / 4.0
        let tw = offset
        let th = offset / 2.0
        fillColor(gray: 0.0)
        rect(x: cx - offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx - offset - tw/2.0, y: cy + offset, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy + offset, width: tw, height: th)
    }
    
}


