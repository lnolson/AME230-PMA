//
//  ViewController.swift
//  
//

import Cocoa
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        
        view.window?.title = "Solar System"
        makeView(width: 1440.0, height: 900.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    // scene properties here
    var bodies: [Body] = []
    
    var earthOrbit = 250.0
    var earthRadius = 15.0
    
    var marsOrbit = 500.0
    var marsRadius = 12.0
    
    var moonOrbit = 50.0
    var moonRadius = 7.0
    
    var phobosOrbit = 75.0
    var phobosRadius = 5.0
    var deimosOrbit = 50.0
    var deimosRadius = 4.0

    
    override func setup() {
        // initialization here
        
        let earth = Body(orbit: earthOrbit, radius: earthRadius)
        bodies.append(earth)
        
        let moon = Body(orbit: moonOrbit, radius: moonRadius)
        moon.thetaVelocity = 0.03
        earth.addChild(body: moon)
        
        let mars = Body(orbit: marsOrbit, radius: marsRadius)
        mars.theta = 2.0
        bodies.append(mars)
        mars.thetaVelocity = 0.007
        mars.spinVelocity = 0.12
        
        let phobos = Body(orbit: phobosOrbit, radius: phobosRadius)
        mars.addChild(body: phobos)
        
        let deimos = Body(orbit: deimosOrbit, radius: deimosRadius)
        deimos.theta = 1.0
        deimos.thetaVelocity = 0.04
        mars.addChild(body: deimos)
        
    }
    
    override func update() {
        background(gray: 0.0)
        
        translate(dx: tin.midX, dy: tin.midY)
        strokeDisable()
        fillColor(red: 0.94, green: 0.91, blue: 0.1, alpha: 1.0)
        ellipse(centerX: 0, centerY: 0, width: 50, height: 50)
        
        // earth orbit
        strokeColor(gray: 0.2)
        fillDisable()
        ellipse(centerX: 0, centerY: 0, width: earthOrbit * 2, height: earthOrbit * 2)
        
        // mars orbit
        ellipse(centerX: 0, centerY: 0, width: marsOrbit * 2, height: marsOrbit * 2)
        
        for body in bodies {
            body.render()
        }
    }

}



