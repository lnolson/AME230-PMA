//
//  ViewController.swift
//  Quadrants
//
//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Quadrants"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        
        // Location of the mouse
        let mouseX = tin.mouseX
        let mouseY = tin.mouseY
        
        // Size of rectangle for drawing
        let w = tin.width / 2
        let h = tin.height / 2
        
        strokeDisable()
        
        if mouseX < tin.midX && mouseY < tin.midY {
            // Mouse is in the bottom, left quadrant.
            fillColor(red: 1, green: 0, blue: 0, alpha: 1)
            rect(x: 0, y: 0, width: w, height: h)
        }
        else if mouseX >= tin.midX && mouseY < tin.midY {
            // Mouse is in the bottom, right quadrant
            fillColor(red: 0, green: 1, blue: 0, alpha: 1)
            rect(x: tin.midX, y: 0, width: w, height: h)
        }
        else if mouseX >= tin.midX && mouseY > tin.midY {
            // Mouse is in the top, right quadrant
            fillColor(red: 0, green: 0, blue: 1, alpha: 1)
            rect(x: tin.midX, y: tin.midY, width: w, height: h)
        }
        else {
            // Mouse is in the top, left quadrant
            // We know that it is in top, left only because if it is not
            // in any of the others, it must be in the top, left.
            fillColor(red: 1, green: 1, blue: 0, alpha: 1)
            rect(x: 0, y: tin.midY, width: w, height: h)
        }
        
    }
    
}


