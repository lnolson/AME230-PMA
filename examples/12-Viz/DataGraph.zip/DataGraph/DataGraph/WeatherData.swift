//
//  WeatherData.swift
//  DataGraph
//
//

import Foundation



class WeatherData {
    
    var data: [WeatherDataPoint]
    
    
    init(contentsOfFile csvName: String) {
        data = []
        if let pathName = Bundle.main.path(forResource: csvName, ofType: "") {
            do {
                let contents = try String(contentsOfFile: pathName)
                let rows = contents.components(separatedBy: "\n")
                print("There are \(rows.count) lines in the file.")
                for index in 1 ..< rows.count {
                    let dataPoint = WeatherDataPoint(line: rows[index])
                    if dataPoint.date != "None" {
                        data.append(dataPoint)
                    }
                }
            }
            catch {
                print("Error reading \(pathName): \(error.localizedDescription)")
            }
        }
        else {
            print("Unable to locate the file \(csvName)")
        }
    }
    
}

let separators = CharacterSet([",","\r","\n"])

struct WeatherDataPoint {
    var date: String
    var actual_mean_temp: Int
    var actual_min_temp: Int
    var actual_max_temp: Int
    var average_min_temp: Int
    var average_max_temp: Int
    var record_min_temp: Int
    var record_max_temp: Int
    var record_min_temp_year: Int
    var record_max_temp_year: Int
    var actual_precipitation: Double
    var average_precipitation: Double
    var record_precipitation: Double
    
    init(line: String) {
        date = "None"
        actual_mean_temp = 0
        actual_min_temp = 0
        actual_max_temp = 0
        average_min_temp = 0
        average_max_temp = 0
        record_min_temp = 0
        record_max_temp = 0
        record_min_temp_year = 0
        record_max_temp_year = 0
        actual_precipitation = 0.0
        average_precipitation = 0.0
        record_precipitation = 0.0
        let fields = line.components(separatedBy: separators)
        if fields.count == 13 {
            date = fields[0]
            if let value = Int(fields[1]) {
                actual_mean_temp = value
            }
            if let value = Int(fields[2]) {
                actual_min_temp = value
            }
            if let value = Int(fields[3]) {
                actual_max_temp = value
            }
            if let value = Int(fields[4]) {
                average_min_temp = value
            }
            if let value = Int(fields[5]) {
                average_max_temp = value
            }
            if let value = Int(fields[6]) {
                record_min_temp = value
            }
            if let value = Int(fields[7]) {
                record_max_temp = value
            }
            if let value = Int(fields[8]) {
                record_min_temp_year = value
            }
            if let value = Int(fields[9]) {
                record_max_temp_year = value
            }
            if let value = Double(fields[10]) {
                actual_precipitation = value
            }
            if let value = Double(fields[11]) {
                average_precipitation = value
            }
            if let value = Double(fields[12]) {
                record_precipitation = value
            }
        }
    }
}
