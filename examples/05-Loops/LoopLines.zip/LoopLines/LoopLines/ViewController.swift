//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Lines"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        // A Loop that draws vertical lines, until it hits the right edge
        // of the view
        
        var x = 20.0
        while x + 20.0 <= tin.width {
            
            line(x1: x, y1: 50, x2: x, y2: 150)
            
            x += 40.0
            
        }
        
        
        view?.stopUpdates()
    }
    
}

