//
//  ViewController.swift
//  
//  Two rotating squares.
//  - use pushState and popState to save/restore the current graphics state.
//  - draw the square so that the origin (0,0) is at the center of the square.
//  - use translate to position the square in the view.
//  - use rotate
//  - be careful about the order of translate, rotate.

import Cocoa
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        
        view.window?.title = "Demo"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var angle = 0.0
    
    
    
    override func update() {
        background(gray: 0.5)
        
        // Blue square rotates counter-clockwise
        pushState()
        translate(dx: 300, dy: 300)
        rotate(by: angle)
        fillColor(red: 0.2, green: 0.2, blue: 0.9, alpha: 1)
        rect(x: -50, y: -50, width: 100, height: 100)
        popState()

        // Green square rotates clockwise
        pushState()
        translate(dx: 500, dy: 300)
        rotate(by: -angle)
        fillColor(red: 0.2, green: 0.9, blue: 0.2, alpha: 1)
        rect(x: -50, y: -50, width: 100, height: 100)
        popState()

        angle += 0.05
        
    }
    
    
}

