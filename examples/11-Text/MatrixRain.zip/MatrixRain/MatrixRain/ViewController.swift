//
//  ViewController.swift
//
//  Digital Rain ala The Matrix opening titles.
//  This project was inspired by a guest tutorial by Emily Xie at The Coding Train.
//  https://www.youtube.com/watch?v=S1TQCi9axzg
//  (That project is created using p5.js)
//
//  See the original Matrix title at
//  https://www.youtube.com/watch?v=Or2m7rYHb_Q
//



import Cocoa
import Tin
import CoreImage



class ViewController: TController {
    var scene: Scene!
    
    override func viewWillAppear() {
        view.window?.title = "What is the Matrix?"
        makeView(width: 1280.0, height: 720.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
        
        // Use a CoreImage bloom filter to add a glowy effect to the view.
        // Note that this will add a glowy effect to everything in the view!
        if let bloom = CIFilter(name: "CIBloom", parameters: ["inputIntensity": 0.75]) {
            view.contentFilters = [bloom]
        }
        
        
    }

}


class Scene: TScene {
    
    var streams: [Stream] = []
    
    
    override func setup() {
        // each stream is a column of characters.
        // Add streams across the entire view.
        var x = 0.0
        while x < tin.width {
            let stream = Stream()
            stream.generateSymbols(x: x, y: random(min: tin.height, max: tin.height + 1000.0))
            streams.append(stream)
            x += 30.0
        }
    }
    
    override func update() {
        background(gray: 0.0)
        
        for stream in streams {
            stream.render()
        }
    }
    
}


// A class to represent an individual symbol. (one character)
class Symbol {
    static var font = TFont(fontName: "Osaka", ofSize: 28.0)
    
    var x: Double
    var y: Double
    var value: String
    var speed: Double
    
    // If first is true, this symbol is the first symbol in a stream.
    var first: Bool
    
    // transparency
    var alpha: Double
    
    // after switchInterval frames go by, the symbol will change to
    // another random character.
    var switchInterval: Int
    
    init(x: Double, y: Double, speed: Double, first: Bool, alpha: Double) {
        self.x = x
        self.y = y
        self.speed = speed
        self.first = first
        self.alpha = alpha
        switchInterval = Int(random(min: 3, max: 25))
        value = ""
        randomSymbol()
    }
    
    // If it is time, randomly switch to another character.
    func randomSymbol() {
        let charType = Int(round(random(min: 0, max: 20)))
        if tin.frameCount % switchInterval == 0 {
            if charType > 1 {
                // Katakana
                let scalar = 0x30A0 + Int(random(min: 0, max: 96))
                if let unicode = UnicodeScalar(scalar) {
                    value = String(unicode)
                }
            }
            else {
                value = String(Int(random(min: 0, max: 10)))
            }
        }
    }
    
    // draw a symbol
    func render() {
        if first {
            fillColor(red: 0.7490, green: 1.0, blue: 0.867, alpha: alpha)
        } else {
            fillColor(red: 0.0, green: 1.0, blue: 0.2745, alpha: alpha)
        }
        text(message: value, font: Symbol.font, x: x, y: y)
        randomSymbol()
        if y < 0.0 {
            y = tin.height
        }
        else {
            y -= speed
        }
    }
}


// A class to represent a vertical strip of symbols.
class Stream {
    var symbols: [Symbol]
    var speed: Double
    
    init() {
        symbols = []
        speed = random(min: 5.0, max: 25.0)
    }
    
    // This is called once, to generate all the symbols in this stream.
    func generateSymbols(x: Double, y: Double) {
        var alpha = 1.0
        var first = Int(random(min: 0, max: 4)) == 1
        let count = Int(random(min: 5, max: 35))
        
        var sy = y
        for _ in 0...count {
            let symbol = Symbol(x: x, y: sy, speed: speed, first: first, alpha: alpha)
            symbol.randomSymbol()
            symbols.append(symbol)
            
            let fadeInterval = 1.6
            alpha -= (1.0 / Double(count)) / fadeInterval
            first = false
            sy += 28.0
        }
    }
    
    // draw the entire stream.
    func render() {
        for symbol in symbols {
            symbol.render()
        }
    }
}


