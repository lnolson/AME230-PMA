//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Meter"
        makeView(width: 1000.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        // circle at mouse pointer position (direct mapping)
        ellipse(centerX: tin.mouseX, centerY: tin.mouseY, width: 40, height: 40)
        
        
        // Create a (vertical) meter that fills based on the X position of mouse.
        
        let width = 40.0
        let height = 400.0
        let meterX = tin.midX - width / 2.0
        let meterY = tin.midY - height / 2.0
        
        // base background of meter
        strokeDisable()
        fillColor(gray: 0.0)
        rect(x: meterX, y: meterY, width: width, height: height)

        // ratio is a value between 0 - 1, horizonal position of mouse.
        // 0 at left edge, 1 at right edge of view, 0.5 in middle.
        let ratio = tin.mouseX / tin.width
        
        // h is the current height of the filled segment, based on mouse position.
        let h = height * ratio
        
        // fill the meter
        fillColor(red: 1, green: 1, blue: 0, alpha: 1)
        rect(x: meterX, y: meterY, width: width, height: h)
        
        // outline the entire meter
        fillDisable()
        strokeColor(gray: 1.0)
        rect(x: meterX, y: meterY, width: width, height: height)
        
        // create a triangle pointer to the top level of the
        // current meter value
        strokeDisable()
        fillColor(gray: 1.0)
        
        let y1 = meterY + h
        triangle(x1: meterX - 4.0, y1: y1, x2: meterX - 30, y2: y1 - 10, x3: meterX - 30, y3: y1 + 10)
        
        
        // Your drawing code should be above this comment.
        // *************************************************
        
        
    }
    
}

