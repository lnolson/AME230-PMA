//
//  Circle.swift
//

import Cocoa
import Tin


class Circle {
    var x: Double
    var y: Double
    var radius: Double
    
    
    init(x: Double, y: Double, radius: Double) {
        self.x = x
        self.y = y
        self.radius = radius
    }
    
    
    func render() {
        let d = radius * 2.0
        ellipse(centerX: x, centerY: y, width: d, height: d)
    }
    

}
