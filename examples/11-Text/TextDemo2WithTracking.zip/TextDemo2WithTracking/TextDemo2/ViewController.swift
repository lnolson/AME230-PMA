//
//  ViewController.swift

//  Drawing a string in the view.
//  This example draws the text one character at a time.
//
//  Drag the mouse to space the letters apart.
//  Note, this spacing effect doesn't use any character kerning info...
//  as a result, its pretty crude.

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Text 2"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
        scene.updateTracking(dx: tin.mouseX - tin.pmouseX)
    }

}


class Scene: TScene {
    
    var font1 = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 140.0)
    var message = "Arizona"
    var tracking = 1.0
    
    
    override func update() {
        background(gray: 0.5)
        
        lineWidth(1.0)
        strokeColor(gray: 0)
        line(x1: 0, y1: tin.midY, x2: tin.width, y2: tin.midY)
        line(x1: tin.midX, y1: 0, x2: tin.midX, y2: tin.height)
        
        
        fillColor(gray: 1)
        font1.horizontalAlignment = .center
        
        // The size method returns an NSSize object.
        // NSSize has properties width and height.
        // (Truth be told, NSSize is an alias for CGSize)
        // Notice however, that width and height properties are of type
        // CGFloat, instead of Double.
        let messageSize = font1.size(ofMessage: message)
        let messageWidth = Double(messageSize.width)
        
        var x = tin.midX - ((messageWidth * tracking) / 2.0 )
        let y = tin.midY
        
        for c in message {
            let letterSize = font1.size(ofMessage: "\(c)")
            let letterWidth = Double(letterSize.width)
            let xc = (letterWidth / 2.0) + x
            
            text(message: "\(c)", font: font1, x: xc , y: y)

            x += letterWidth * tracking
        }
    }
    
    
    func updateTracking(dx: Double) {
        tracking += dx * 0.01
    }
    
}

