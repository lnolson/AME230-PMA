//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Text 1"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    // Make a TFont object used for drawing text.
    // You can lookup font names in the Font Book application.
    // Here is a list of the default fonts in macOS 10.12.
    // https://support.apple.com/en-us/HT206872
    var font1 = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 140.0)
    
    
    
    override func update() {
        background(gray: 0.5)
        
        lineWidth(1.0)
        strokeColor(gray: 0)
        line(x1: 0, y1: tin.midY, x2: tin.width, y2: tin.midY)
        line(x1: tin.midX, y1: 0, x2: tin.midX, y2: tin.height)
        
        
        fillColor(gray: 1)
        
        // The horizontalAlignment property controls x axis position of drawing.
        // options are left, center, and right.
        font1.horizontalAlignment = .center
        
        // There is also a verticalAlignment property that has values of
        // top, center, baseline, and bottom. (baseline is default)
        
        // The text function draws a string, using the given font, at the
        // given location. Color of the text is based on the current fill color.
        text(message: "Arizona", font: font1, x: tin.midX, y: tin.midY)
    }
    
}

