//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Circles"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    
    override func update() {
        
        background(gray: 0.5)
    
        // This loop will have 1000 iterations.
        // Each iteration draws one circle.
        
        var count = 0
        while count < 1000 {
            
            // Use random numbers for the position and size of the circle.
            let x = random(max: tin.width)
            let y = random(max: tin.height)
            let w = random(min: 10.0, max: 100.0)
            
            // Use random numbers for the color
            let r = random(min: 0, max: 1)
            let g = random(min: 0, max: 1)
            let b = random(min: 0, max: 1)
            // Random alpha (transparency)
            let a = random(min: 0.6, max: 0.8)
            
            fillColor(red: r, green: g, blue: b, alpha: a)
            ellipse(centerX: x, centerY: y, width: w, height: w)
            
            count = count + 1
        }
        //
        
        
        view?.stopUpdates()
    }
    
}

