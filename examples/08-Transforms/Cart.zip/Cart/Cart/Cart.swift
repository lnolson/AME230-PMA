//
//  Cart.swift
//  Cart
//
//  Created by Loren Olson on 10/26/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin


class Cart {
    // x & y are the position of the cart
    var x = 600.0
    var y = 200.0
    // r is the radius of the wheels
    var r = 40.0
    // size of the cart body
    var bodyWidth = 200.0
    var bodyHeight = 70.0
    
    
    func render() {
        pushState()
        
        translate(dx: x, dy: y)
        
        // Body of the cart
        fillColor(gray: 1.0)
        lineWidth(3)
        strokeColor(gray: 0.1)
        rect(x: -bodyWidth/2.0, y: 0.0, width: bodyWidth, height: bodyHeight)
        
        // Two wheels
        let wheelBase = (bodyWidth / 2.0) * 0.55
        wheel(wx: -wheelBase)
        wheel(wx:  wheelBase)
        
        popState()
    }
    
    
    func wheel(wx: Double) {
        pushState()
        
        translate(dx: wx, dy: 0.0)
        // rotate the wheel based on x position of cart.
        let a = -x / r
        rotate(by: a)
        
        // The wheel is drawn at the origin.
        ellipse(centerX: 0.0, centerY: 0.0, width: r * 2.0, height: r * 2.0)
        line(x1: 0.0, y1: -r, x2: 0.0, y2: r)
        line(x1: -r, y1: 0.0, x2: r, y2: 0.0)

        popState()
    }
    
    
    func move(dx: Double) {
        x += dx
    }
}
