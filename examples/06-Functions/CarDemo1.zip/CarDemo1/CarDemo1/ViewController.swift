//
//  ViewController.swift
//  Circle Demo
//
//

import Cocoa
import Tin


class ViewController: TController {

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Car Demo"
        makeView(width: 1000.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var x1 = 100.0
    var y1 = 200.0
    
    var x2 = 200.0
    var y2 = 300.0
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        
        drawCar(x: x1, y: y1, size: 64.0)
        drawCar(x: x2, y: y2, size: 128.0)
        
        x1 = x1 + 1.0
        if x1 > tin.width {
            x1 = -64.0
        }
        
        x2 = x2 + 2.0
        if x2 > tin.width {
            x2 = -128.0
        }
        
    }
    
    
    func drawCar(x: Double, y: Double, size: Double) {
        
        strokeColor(gray: 0.0)
        fillColor(gray: 0.8)
        rect(x: x, y: y, width: size, height: size/2.0)
        
        let offset = size / 4.0
        let cx = x + size / 2.0
        let cy = y + size / 4.0
        let tw = offset
        let th = offset / 2.0
        fillColor(gray: 0.0)
        rect(x: cx - offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx - offset - tw/2.0, y: cy + offset, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy + offset, width: tw, height: th)
    }

    
}


