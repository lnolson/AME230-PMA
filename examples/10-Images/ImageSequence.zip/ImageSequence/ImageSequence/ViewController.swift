//
//  ViewController.swift

//

// Demo of an animated image sequence.
//
// Use any keypress to reset to the initial state.
// Press the mouse button to start the sequence.
// The explosion image sequence was published by the good people that
// make Unity.


import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Image Sequence"
        makeView(width: 1000.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    override func mouseUp(with event: NSEvent) {
        scene.boom()
    }
    
    
    override func keyUp(with event: NSEvent) {
        scene.reset()
    }

}


class Scene: TScene {
    // images is an array to hold all of the explosion images.
    var images: [TImage] = []
    
    // current is an Int that specifies which image from the images array
    // should be drawn.
    var current = 0
    
    // When isPlaying is true, the image sequence is "playing" that is,
    // advancing to the next image.
    var isPlaying = false

    // Two TImage objects for the two logos.
    var sundevils = TImage(contentsOfFileInBundle: "sundevils.png")!
    var wildcats = TImage(contentsOfFileInBundle: "wildcats.png")!
    
    // These alpha values are used for the transparency of the logo and explosion.
    // When the explosion happens, the logo is faded out quickly. (over 30 frames)
    // The explosion is also faded out at the end, because the image sequence would
    // otherwise "snap" off visually.
    var imageAlpha = 1.0
    var wildcatAlpha = 1.0
    
    
    override func setup() {
        reset()
        // Load all 100 images into the images array.
        for i in 0...99 {
            let name = String(format: "explosion01-light-frame.%05d.png", arguments: [i])
            if let img = TImage(contentsOfFileInBundle: name) {
                images.append(img)
            }
        }
    }
    
    func reset() {
        current = 0
        wildcatAlpha = 1.0
        isPlaying = false
    }
    
    func boom() {
        isPlaying = !isPlaying
    }
    
    
    override func update() {
        background(gray: 0.0)
        
        // Draw the ASU logo
        image(image: sundevils, x: (tin.midX / 2.0) - 150.0, y: tin.midY - 150.0)
        
        // Draw the UofA logo
        pushState()
        setAlpha(wildcatAlpha)  // set transparency
        image(image: wildcats, x: tin.midX + (tin.midX / 2.0) - 100.0, y: tin.midY - 100.0, width: 200.0, height: 200.0)
        popState()
        
        let t = Double(current - 20) / 30.0
        wildcatAlpha = smoothstep(startValue: 1.0, endValue: 0.0, t: t)
        
        if isPlaying {
            // Draw the explosion effect.
            let explosion = images[current]
            let x = tin.midX + (tin.midX / 2.0) - 250.0
            let y = tin.midY - 180.0
            pushState()
            setAlpha(imageAlpha)
            image(image: explosion, x: x, y: y, width: 500, height: 500)
            popState()
            
            let t = (30.0 - Double(images.count - current)) / 30.0
            imageAlpha = smoothstep(startValue: 1.0, endValue: 0.0, t: t)
            
            // Advance to the next image in the image sequence.
            current = current + 1
            if current >= images.count {
                current = current - 1
                isPlaying = false
                imageAlpha = 1.0
            }
        }
        

    }
}

