//
//  ViewController.swift
//  Iso Cubes - with a function to draw a cube
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Iso Cubes"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
    
        lineWidth(1)
        
        var count = 6
        var x0 = 100.0
        var y = 50.0
        while count >= 1 {
            
            var x = x0
            var i = 0
            while i < count {
                cube(cubeX: x, cubeY: y, width: 100, height: 100)
                
                x += 100.0
                i += 1
            }
            
            count = count - 1
            y += 75.0
            x0 += 50.0
        }
        
        
        view?.stopUpdates()
    } // end of update
    
    
    //
    // cube
    // A function to draw one iso-cube.
    //
    func cube(cubeX: Double, cubeY: Double, width: Double, height: Double) {
        
        let cubeMidX = cubeX + (width / 2.0)
        let cubeMaxX = cubeX + width
        let cubeY1 = cubeY + (height / 4.0)
        let cubeY2 = cubeY + (height / 4.0) * 2.0
        let cubeY3 = cubeY + (height / 4.0) * 3.0
        let cubeMaxY = cubeY + height
        
        fillColor(gray: 0.4)
        pathBegin()
        pathVertex(x: cubeX, y: cubeY1)
        pathVertex(x: cubeMidX, y: cubeY)
        pathVertex(x: cubeMidX, y: cubeY2)
        pathVertex(x: cubeX, y: cubeY3)
        pathClose()
        
        fillColor(gray: 0.7)
        pathBegin()
        pathVertex(x: cubeMidX, y: cubeY)
        pathVertex(x: cubeMaxX, y: cubeY1)
        pathVertex(x: cubeMaxX, y: cubeY3)
        pathVertex(x: cubeMidX, y: cubeY2)
        pathClose()
        
        fillColor(gray: 0.3)
        pathBegin()
        pathVertex(x: cubeX, y: cubeY3)
        pathVertex(x: cubeMidX, y: cubeY2)
        pathVertex(x: cubeMaxX, y: cubeY3)
        pathVertex(x: cubeMidX, y: cubeMaxY)
        pathClose()
    }
    
}

