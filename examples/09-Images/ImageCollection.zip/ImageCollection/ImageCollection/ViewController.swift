//
//  ViewController.swift

//  Collection example.
//  Load 9 images into an array of TImage objects.
//  Display one image at a time.
//  Advance thru the images by clicking the mouse.

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Image Collection"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    override func mouseUp(with event: NSEvent) {
        scene.next()
    }

}


class Scene: TScene {
    // photos is an array for holding TImage objects.
    var photos: [TImage] = []
    
    // currentImage is the index of the currently displayed image.
    var currentImage = 0
    
    //
    var font = TFont(fontName: "Helvetica Light", ofSize: 16.0)
    
    override func setup() {
        // Load the 10 images from disk, store objects in photos array.
        for i in 1...9 {
            let name = "mars_\(i).jpg"
            if let img = TImage(contentsOfFileInBundle: name) {
                photos.append(img)
            }
        }
        
        font.horizontalAlignment = .left
    }
    
    
    override func update() {
        background(gray: 0.9)
        
        let x = tin.midX - (photos[currentImage].width / 2.0)
        let y = tin.midY - (photos[currentImage].height / 2.0)
        
        photos[currentImage].draw(x: x, y: y)
        
        fillColor(gray: 0.1)
        text(message: "Press mouse button to advance to the next image", font: font, x: 10, y: 10)
    }
    
    
    func next() {
        // Advance to the next index value.
        // If the value is greater than the number
        // of images in the array, loop back to the first image.
        currentImage = (currentImage + 1) % photos.count
    }
}

