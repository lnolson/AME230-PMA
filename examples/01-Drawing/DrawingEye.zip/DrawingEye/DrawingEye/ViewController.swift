//
//  ViewController.swift
//  Drawing
//
//  Eye created by Jennifer Weiler


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Drawing Eye"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.3)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        strokeDisable()
        
        let x = 250.0
        let y = 200.0
        
        ///////eyeball
        fillColor(red: 0.8, green: 0.6, blue: 0.6, alpha: 1.0)
        ellipse(centerX: x + 30, centerY: y + 80, width: 80, height: 80)
        fillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        ellipse(centerX: x + 155, centerY: y + 110, width: 310, height: 220)
        fillColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 100, width: 300, height: 200)
        fillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 100, width: 200, height: 200)
        
        // iris
        fillColor(red: 0.1, green: 0.3, blue: 0.7, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 100, width: 180, height: 180)
        fillColor(red: 0.3, green: 0.5, blue: 0.9, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 85, width: 150, height: 150)
        fillColor(red: 0.4, green: 0.6, blue: 1.0, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 70, width: 120, height: 120)
        
        // pupil
        fillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
        ellipse(centerX: x + 150, centerY: y + 100, width: 100, height: 100)
        
        //highlights
        fillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        ellipse(centerX: x + 75, centerY: y + 125, width: 50, height: 50)
        ellipse(centerX: x + 192.5, centerY: y + 47.5, width: 25, height: 25)
        
        // Your drawing code should be above this comment.
        // *************************************************
        
        view?.stopUpdates()
    }
    
}

