//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "DrawingHouse"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        // sky
        strokeDisable()
        fillColor(red: 0.1, green: 0.2, blue: 0.4, alpha: 1.0)
        rect(x: 0.0, y: 0.0, width: 800.0, height: 600.0)
        
        // ground
        fillColor(red: 0.1, green: 0.4, blue: 0.15, alpha: 1.0)
        rect(x: 0.0, y: 0.0, width: 800.0, height: 300.0)

        // house
        
        fillColor(gray: 0.85)
        rect(x: 300.0, y: 200.0, width: 200.0, height: 200.0)
        
        // peak
        triangle(x1: 300.0, y1: 400.0, x2: 500.0, y2: 400.0, x3: 400.0, y3: 500.0)
        
        // roof
        strokeColor(gray: 0.5)
        lineWidth(9.0)
        pathBegin()
        pathVertex(x: 300, y: 400)
        pathVertex(x: 400, y: 500)
        pathVertex(x: 500, y: 400)
        pathEnd()
        
        
        // door
        strokeColor(gray: 0.0)
        lineWidth(2.0)
        fillColor(gray: 0.8)
        rect(x: 320.0, y: 200.0, width: 60.0, height: 150.0)
        
        // window
        fillColor(gray: 0.75)
        rect(x: 410.0, y: 240.0, width: 60.0, height: 90.0)
        lineWidth(4.0)
        strokeColor(gray: 0.2)
        line(x1: 410.0, y1: 285.0, x2: 470.0, y2: 285.0)
        line(x1: 440.0, y1: 240.0, x2: 440.0, y2: 330.0)
        
        
        // moon
        strokeDisable()
        fillColor(gray: 0.85)
        ellipse(centerX: 650, centerY: 500, width: 80, height: 80)
        
        fillColor(red: 0.1, green: 0.2, blue: 0.4, alpha:1.0)
        ellipse(centerX: 670, centerY: 500, width: 70, height: 70)
    
        // Your drawing code should be above this comment.
        // *************************************************
        
        view?.stopUpdates()
    }
    
}

