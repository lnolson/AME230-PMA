//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        bigCircle(x: 200.0, y: 400.0)
        bigCircle(x: 400.0, y: 300.0)
        
        bigSquare(x: 250, y: 150)
        
    } // end of update function
    
    
    // a simple function to draw a circle.
    // two input parameters.
    func bigCircle(x: Double, y: Double) {
        fillColor(red: 1, green: 0.9, blue: 0.8, alpha: 1)
        ellipse(centerX: x, centerY: y, width: 500.0, height: 500.0)
    }
    
    
    // a function to draw a square.
    // two input parameters.
    func bigSquare(x: Double, y: Double) {
        fillColor(red: 0.4, green: 0.7, blue: 1, alpha: 1)
        rect(x: x, y: y, width: 300, height: 300)
    }
    
}


