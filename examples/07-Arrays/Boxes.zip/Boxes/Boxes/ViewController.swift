//
//  ViewController.swift
//
//  Another array demo.
//  The height of the boxes is saved in the array boxHeights.


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 1000.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    // store the box heights in this array
    var boxHeights: [Double] = []
    
    
    override func setup() {
        // The setup function is called once, right before the
        // first time that update is called.
        
        // Setup the initial values for the box heights.
        for _ in 0...49 {
            boxHeights.append(20.0)
        }
    }
    
    override func update() {
        background(gray: 0.5)
        
        var x = 0.0
        let y = 10.0
        let w = 20.0
        
        var i = 0
        while i < 50 {
            
            var h = boxHeights[i]
            
            if tin.mouseX > x && tin.mouseX < x + w && tin.mouseY > y && tin.mouseY < y + h {
                // This mouse pointer is inside this box.
                fillColor(red: 1, green: 0, blue: 0, alpha: 1)
                // Make the box a little taller.
                boxHeights[i] += 5.0
                h += 5.0
            }
            else {
                // The mouse pointer is NOT inside this box.
                fillColor(red: 1, green: 1, blue: 1, alpha: 1)
            }
            
            rect(x: x, y: y, width: w, height: h)
            
            x = x + w
            
            i = i + 1
        }
    }
    
}

