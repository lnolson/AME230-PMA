//
//  Letter.swift
//  TextScatter
//
//  A class to represent one letter.

import Foundation
import Tin



class Letter {
    var letter: String
    var font: TFont
    var homeX: Double
    var homeY: Double
    var scatterX: Double
    var scatterY: Double
    var scatterAngle: Double
    
    
    init(letter: String, x: Double, y: Double, font: TFont) {
        self.letter = letter
        self.homeX = x
        self.homeY = y
        self.font = font
        self.scatterX = random(min: 100, max: tin.width - 100)
        self.scatterY = random(min: 100, max: tin.height - 100)
        self.scatterAngle = random(min: -1.0 * .pi, max: .pi)
    }
    
    
    // parameter t is expected to be in the range 0 - 1
    // when t is 0, the letter will be at the home position.
    // when t is 1, the letter will be at the scatter position.
    // values between 0 and 1 are interpolated using smoothstep.
    func render(t: Double) {
        let x = smoothstep(startValue: homeX, endValue: scatterX, t: t)
        let y = smoothstep(startValue: homeY, endValue: scatterY, t: t)
        let angle = smoothstep(startValue: 0.0, endValue: scatterAngle, t: t)
        
        pushState()
        translate(dx: x, dy: y)
        rotate(by: angle)
        font.horizontalAlignment = .center
        text(message: letter, font: font, x: 0, y: 0)
        popState()
    }
    
    

}
