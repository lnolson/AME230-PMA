//
//  ViewController.swift
//
//  DistDemo
//  A function that calculates the distance between two points.
//  The distance value is returned as a Double.


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    let x1 = 400.0
    let y1 = 300.0
    let radius = 100.0
    
    override func update() {
        background(gray: 0.5)
        
        let distanceCircleToMouse = distance(x1: x1, y1: y1, x2: tin.mouseX, y2: tin.mouseY)
        
        // If the mouse pointer is inside the circle,
        // set the fill color to red.
        // otherwise, the fill color is white.
        if distanceCircleToMouse < radius {
            fillColor(red: 1, green: 0, blue: 0, alpha: 1)
        }
        else {
            fillColor(gray: 1.0)
        }
        
        ellipse(centerX: x1, centerY: y1, width: radius * 2, height: radius * 2)
        
        line(x1: x1, y1: y1, x2: tin.mouseX, y2: tin.mouseY)
        
    }
    
    
    // calculate the distance from (x1,y1) to (x2,y2)
    // result is returned as a Double value.
    func distance(x1: Double, y1: Double, x2: Double, y2: Double) -> Double {
        let a = y2 - y1
        let b = x2 - x1
        let c = sqrt(a * a + b * b)
        return c
    }
    
}

