//
//  Body.swift
//  Orbit
//
//  Created by Loren Olson on 10/26/17.
//  Copyright © 2017 ASU. All rights reserved.
//

import Foundation
import Tin


class Body {
    var orbit: Double           // distance from parent
    var theta: Double           // current angle of orbit
    var thetaVelocity: Double   // speed of orbit
    var spin: Double            // current angle of body (rotation)
    var spinVelocity: Double    // speed of spin
    var radius: Double          // radius of body
    var children: [Body]
    
    init(orbit: Double, radius: Double) {
        self.orbit = orbit
        self.radius = radius
        theta = 0.0
        thetaVelocity = 0.01
        spin = 0
        spinVelocity = 0.11
        children = []
    }
    
    func render() {
        pushState()
        lineWidth(1)
        
        rotate(by: theta)
        translate(dx: orbit, dy: 0.0)
        
        for child in children {
            child.render()
        }
        
        rotate(by: spin)
        fillColor(gray: 0.8)
        ellipse(centerX: 0, centerY: 0, width: radius*2.0, height: radius*2.0)
        line(x1: 0, y1: radius, x2: 0, y2: -radius)
        line(x1: radius, y1: 0, x2: -radius, y2: 0)
        
        popState()
        
        theta += thetaVelocity
        spin += spinVelocity
    }
    
    func addChild(body: Body) {
        children.append(body)
    }
}
