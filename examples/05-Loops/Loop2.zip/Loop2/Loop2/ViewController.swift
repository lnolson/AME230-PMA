//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        // x is the starting position for the first block.
        var x = 0.0
        // width is the width of one block. (There will be 33 blocks)
        let width = tin.width / 33.0
        // height is the height of the first block.
        var height = 15.0
        // delta is how much the height of the blocks change each step.
        let delta = 20.0
        // count is used to "number" the blocks.
        var count = 0
        
        while x < tin.width {
            
            if count % 2 == 0 {
                // count is even, make this block white
                fillColor(red: 1, green: 1, blue: 1, alpha: 1)
            }
            else {
                // count is odd, make this block red
                fillColor(red: 1, green: 0, blue: 0, alpha: 1)
            }
            rect(x: x, y: 0, width: width, height: height)

            x = x + width
            if x <= tin.midX {
                // on the left half, the blocks are getting taller.
                height = height + delta
            }
            else {
                // on the right half, the blocks are getting shorter.
                height = height - delta
            }
            
            count = count + 1
        }
        
        
    }
    
}

