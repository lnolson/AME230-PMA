//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Parallax"
        makeView(width: 1200.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

} // end of ViewController class


class Scene: TScene {
    // The ! after TImage is important here.
    // We don't create the TImage object until the setup function runs.
    var far: TImage!
    var mid: TImage!
    var runner: TImage!
    var coyote: TImage!
    var text1: TImage!
    
    
    override func setup() {
        far = TImage(contentsOfFileInBundle: "far_bg.png")
        mid = TImage(contentsOfFileInBundle: "mid.png")
        runner = TImage(contentsOfFileInBundle: "road-runner.png")
        coyote = TImage(contentsOfFileInBundle: "coyote.png")
        text1 = TImage(contentsOfFileInBundle: "text_1.png")
    } // end of setup function
    
    
    override func update() {
        background(gray: 0.5)
        
        let farX = remap(value: tin.mouseX, start1: 0, stop1: tin.width, start2: -200, stop2: -180)
        image(image: far, x: farX, y: 0)
        
        
        let midX = remap(value: tin.mouseX, start1: 0, stop1: tin.width, start2: -200, stop2: 0)
        image(image: mid, x: midX, y: 0)
        
        let runnerX = remap(value: tin.mouseX, start1: 0, stop1: tin.width, start2: 400, stop2: 800)
        image(image: runner, x: runnerX, y: 187)
        
        let coyoteX = remap(value: tin.mouseX, start1: 0, stop1: tin.width, start2: -100, stop2: 200)
        image(image: coyote, x: coyoteX, y: 184)
        
        let text1X = remap(value: tin.mouseX, start1: 0, stop1: tin.width, start2: 400, stop2: 900)
        image(image: text1, x: text1X, y: 46)
        
        //print("\(tin.mouseX), \(tin.mouseY)")

    } // end of update function
    
} // end of Scene class

