//
//  ViewController.swift
//  FaceDemo
//
//  Move the mouse up and down to create wink.

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Face Demo"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The setup function is called only once, at the beginning.
    override func setup() {
        view?.showStats = false
    }
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        // moving mouse up/down creates the wink.
        
        let ratio = tin.mouseY / tin.height
        
        let faceX = tin.midX
        let faceY = tin.midY
        
        strokeDisable()
        fillColor(red: 0.1, green: 0.05, blue: 0, alpha: 0.3)
        ellipse(centerX: faceX - 3, centerY: faceY - 3, width: 200, height: 200)
        
        fillColor(red: 1, green: 0.8, blue: 0, alpha: 1)
        ellipse(centerX: faceX, centerY: faceY, width: 200, height: 200)
        
        
        // Eyes
        let eyeY = faceY + 15.0
        fillColor(red: 0.4, green: 0.2, blue: 0, alpha: 1)
        ellipse(centerX: faceX - 40, centerY: eyeY, width: 20, height: 30)
        
        let rightBlinkHeight = 25.0 * ratio + 5.0
        let rightBlinkWidth = 20 + (1.0 - ratio) * 5.0
        ellipse(centerX: faceX + 40, centerY: eyeY, width: rightBlinkWidth, height: rightBlinkHeight)
        
        // Brows
        strokeColor(red: 0.4, green: 0.2, blue: 0, alpha: 1)
        fillDisable()
        lineWidth(4)
        pathBegin()
        pathVertex(x: faceX - 35, y: faceY + 50)
        pathVertex(x: faceX - 50, y: faceY + 48)
        pathVertex(x: faceX - 60, y: faceY + 44)
        pathVertex(x: faceX - 70, y: faceY + 35)
        pathEnd()
        
        let offset1 = 15.0 * ratio
        let offset2 = 13.0 * ratio
        let offset3 = 9.0 * ratio
        pathBegin()
        pathVertex(x: faceX + 35, y: faceY + 35 + offset1)
        pathVertex(x: faceX + 50, y: faceY + 35 + offset2)
        pathVertex(x: faceX + 60, y: faceY + 35 + offset3)
        pathVertex(x: faceX + 70, y: faceY + 35)
        pathEnd()
        
        // Mouth
        
        lineWidth(3)
        fillEnable()
        
        let mouthLeftX = faceX - 40
        let mouthLeftY = faceY - 40
        let mouthRightX = faceX + 40
        let mouthRightY = faceY - 40
        
        pathBegin()
        let leftPoint = CGPoint(x: mouthLeftX, y: mouthLeftY)
        let rightPoint = CGPoint(x: mouthRightX, y: mouthRightY)
        
        pathVertex(x: mouthLeftX, y: mouthLeftY)
        
        let leftLowerTangent = CGPoint(x: faceX - 10, y: faceY - 60)
        let rightLowerTangent = CGPoint(x: faceX + 10, y: faceY - 60)
        
        pathAddCurve(to: rightPoint, control1: leftLowerTangent, control2: rightLowerTangent)
        
        let rightUpperTangent = CGPoint(x: faceX + 10, y: faceY - 50)
        let leftUpperTangent = CGPoint(x: faceX - 10, y: faceY - 50)
        
        pathAddCurve(to: leftPoint, control1: rightUpperTangent, control2: leftUpperTangent)
        
        pathClose()
        pathEnd()
        
        // Your drawing code should be above this comment.
        // *************************************************
        
    }
    
}


