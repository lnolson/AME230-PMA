//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    var currentStyle = ShapeStyle.rectangle
    
    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    override func mouseUp(with event: NSEvent) {
        super.mouseUp(with: event)
        
        scene.addShape(x: tin.mouseX, y: tin.mouseY, radius: 50.0, style: currentStyle)
    }
    
    override func keyUp(with event: NSEvent) {
        if event.characters == "e" {
            currentStyle = .ellipse
        }
        else if event.characters == "r" {
            currentStyle = .rectangle
        }
        else if event.characters == "s" {
            currentStyle = .star
        }
    }

}


class Scene: TScene {
    
    var shapes: [Shape] = []
    
    override func setup() {
        for _ in 1...50 {
            let x = random(min: 0, max: tin.width)
            let y = random(min: 0, max: tin.height)
            let r = random(min: 10.0, max: 80.0)
//            let choice = random(max: 1.0)
//            var style = ShapeStyle.ellipse
//            if choice < 0.5 {
//                style = .rectangle
//            }
            let style = ShapeStyle.star
            addShape(x: x, y: y, radius: r, style: style)
        }
    }
    
    override func update() {
        background(gray: 0.5)
        
        for shape in shapes {
            shape.render()
        }
    }
    
    func addShape(x: Double, y: Double, radius: Double, style: ShapeStyle) {
        let shape = Shape(x: x, y: y, radius: radius, style: style)
        shapes.append(shape)
    }
    
}

