//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var car1x = 200.0
    var car2x = 100.0
    
    override func update() {
        background(gray: 0.5)
        
        let car1y = 300.0
        let car1size = 80.0
        
        let car2y = 100.0
        let car2size = 60.0
        
        drawCar(x: car1x, y: car1y, size: car1size)
        drawCar(x: car2x, y: car2y, size: car2size)
        
        car1x = car1x + 4.0
        if car1x > tin.width {
            car1x = -car1size
        }
        
        car2x = car2x + 5.0
        if car2x > tin.width {
            car2x = -car2size
        }
    }
    
    
    func drawCar(x: Double, y: Double, size: Double) {
        // body
        strokeColor(gray: 0)
        fillColor(gray: 0.8)
        rect(x: x, y: y, width: size, height: size/2.0)
        
        //wheels
        let offset = size / 4.0
        let cx = x + size / 2.0
        let cy = y + size / 4.0
        let tw = offset
        let th = offset / 2.0
        fillColor(gray: 0.0)
        rect(x: cx - offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy - offset - th, width: tw, height: th)
        rect(x: cx - offset - tw/2.0, y: cy + offset, width: tw, height: th)
        rect(x: cx + offset - tw/2.0, y: cy + offset, width: tw, height: th)
    }
    
}

