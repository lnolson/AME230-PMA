//
//  AnimationStepper.swift
//  Text1
//
//  Created by Loren Olson on 4/9/19.
//  Copyright © 2019 ASU. All rights reserved.
//

import Foundation


class AnimationStepper {
    var count: Int   // current frame
    var length: Int  // duration of animation
    
    
    init(length: Int) {
        count = 0
        self.length = length
    }
    
    // return true if count advances
    // else return false
    @discardableResult func step() -> Bool {
        if count < length {
            count += 1
            return true
        }
        else {
            return false
        }
    }
    
    
    func time() -> Double {
        if count <= 0 {
            return 0.0
        }
        else if count < length {
            return Double(count) / Double(length)
        }
        else {
            return 1.0
        }
    }
    
    
    func reset() {
        count = 0
    }
}
