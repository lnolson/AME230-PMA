//
//  ViewController.swift
//  AKDemo1
//
//
//  AudioKit demo. Uses AudioKit open source framework.
//  Sound file is loaded in scene setup.
//  Click the mouse button to play the sound file.
//  For demo purposes, a delay filter effect is added.

import Cocoa
import AudioKit
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "AudioKit Demo"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func mouseDown(with event: NSEvent) {
        scene.play()
    }

}


class Scene: TScene {
    
    var soundFile: AKAudioFile!
    var player: AKAudioPlayer!
    var mic: AKMicrophone!
    var fft: AKFFTTap!
    
    var tracker: AKFrequencyTracker!
    var silence: AKBooster!
    
    override func setup() {
        do {
            soundFile = try AKAudioFile(readFileName: "drumloop.wav")
            player = try AKAudioPlayer(file: soundFile)
        }
        catch {
            debug(error.localizedDescription)
        }

        let delay = AKDelay(player)
        delay.time = 0.1
        //delay.feedback = 0.01
        //delay.dryWetMix = 0.01

        fft = AKFFTTap(player)

        AudioKit.output = delay
        try! AudioKit.start()
    }
    
    
    override func update() {
        background(gray: 0.5)
        

        let n = fft.fftData.count
        let w = tin.width / Double(n)
        var x = 0.0
        strokeDisable()
        fillColor(gray: 0.25)
        for v in fft.fftData {
            let v2 = sqrt(v)
            let h = remap(value: v2, start1: 0, stop1: 1.0, start2: 2, stop2: tin.height)
            rect(x: x, y: tin.midY - h / 2.0, width: w, height: h)
            x += w
        }
    }
    
    
    func play() {
        player.play()
        
        
    }
    
}




