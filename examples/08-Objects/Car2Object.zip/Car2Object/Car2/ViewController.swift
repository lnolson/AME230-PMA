//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Cars"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var car1 = Car()
    var car2 = Car()
    
    override func setup() {
        car2.x = 50.0
        car2.y = 300.0
        car2.size = 64.0
        car2.velocity = 6.0
    }
    
    override func update() {
        background(gray: 0.5)
        
        car1.move()
        car1.render()
        
        car2.move()
        car2.render()

    }
    
    

    
}

