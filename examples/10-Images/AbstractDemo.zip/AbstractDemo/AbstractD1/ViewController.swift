//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Abstract Portrait"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var photo: TImage!
    
    
    override func setup() {
        // Add code to load the image here, and do any other
        // one time setup tasks.
        photo = TImage(contentsOfFileInBundle: "Yosemite_1200.jpg")
        photo.loadPixels()
        
    } // end of setup method
    
    
    override func update() {
        background(gray: 0.0)
        
        strokeDisable()
        
        for _ in 1...10000 {
            let x = random(min: 0, max: tin.width)
            let y = random(min: 0, max: tin.height)
            let pixelX = Int(x)
            let pixelY = Int(y)
            var color1 = photo.color(atX: pixelX, y: pixelY)
            color1.alpha = 0.35
            color1.setFillColor()
            let w = remap(value: color1.luminance(), start1: 0, stop1: 1, start2: 5.0, stop2: 150.0)
            //ellipse(centerX: x, centerY: y, width: w, height: w)
            pushState()
            translate(dx: x, dy: y)
            let hue = color1.hue
            rotate(by: toRadians(degrees: hue))
            if color1.brightness() < 0.5 {
                rect(x: 0.0 - w/2.0, y: 0.0 - w/2.0, width: w, height: w)
            }
            else {
                ellipse(centerX: 0.0, centerY: 0.0, width: w, height: w)
            }
            popState()
        }
 

        // stop updates - program isn't interactive
        view?.stopUpdates()
    } // end of update method
    
    
 
    
    
} // end of Scene class

