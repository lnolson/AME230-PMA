//
//  ViewController.swift
//  AudioDemo1
//
//
//  AudioDemo. Uses AVFoundation.
//  Sound file is loaded in scene setup.
//  Click the mouse button to play the sound file.

import Cocoa
import AVFoundation
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "AudioDemo1"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func mouseDown(with event: NSEvent) {
        scene.play()
    }

}


class Scene: TScene {
    
    var audioPlayer: AVAudioPlayer!
    
    override func setup() {
        do {
            // In order to use this custom initializer, you must include the
            // AVAudioPlayer extension found below, in your project.
            //
            // Also, note that this initializer can "throw" an exception, so
            // this line must be wrapped in a do block, with a catch clause.
            audioPlayer = try AVAudioPlayer(contentsOfFileInBundle: "drumloop.wav")
        }
        catch {
            // If the AVAudioPlayer init has an error, it will be caught here.
            fatalError(error.localizedDescription)
        }
    }
    
    
    override func update() {
        background(gray: 0.5)
    }
    
    
    func play() {
        audioPlayer.play()
    }
}



extension AVAudioPlayer {
    
    // A small extension that makes it easier to use an audio file
    // that is in the main product bundle.
    public convenience init(contentsOfFileInBundle name: String) throws {
        if let path = Bundle.main.path(forResource: name, ofType: "") {
            let url = URL(fileURLWithPath: path)
            try self.init(contentsOf: url)
        }
        else {
            let error = NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "File does not exist, or isn't readable (\(name))."])
            throw error
        }
    }
    
}
