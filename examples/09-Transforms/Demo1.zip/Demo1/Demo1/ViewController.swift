//
//  ViewController.swift
//  
//

import Cocoa
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        
        view.window?.title = "Demo"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {

    
    override func setup() {
        // initialization here
    }
    
    override func update() {
        background(gray: 0.5)
        
        // This blue circle doesn't move
        fillColor(red: 0.2, green: 0.2, blue: 0.9, alpha: 1)
        ellipse(centerX: 100, centerY: 100, width: 40, height: 40)

        // The red and green circles move with the mouse,
        // because of the translate.
        
        translate(dx: tin.mouseX, dy: tin.mouseY)
        
        fillColor(red: 0.9, green: 0.2, blue: 0.2, alpha: 1)
        ellipse(centerX: 50, centerY: 50, width: 40, height: 40)
        
        fillColor(red: 0.2, green: 0.9, blue: 0.2, alpha: 1)
        ellipse(centerX: 200, centerY: 50, width: 40, height: 40)
        
    }
    
    
}

