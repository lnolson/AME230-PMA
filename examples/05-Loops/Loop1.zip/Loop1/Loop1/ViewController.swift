//
//  ViewController.swift
//
//  This demo uses a while loop to draw a row of multiple shapes.


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        var x = 25.0
        let y = 25.0
        let width = 40.0
        let spacing = 50.0
        
        let xedge = 800.0
        
        while x < xedge {
            
            // Instructions for drawing one target graphic
            strokeDisable()
            fillColor(red: 1, green: 0, blue: 0, alpha: 1)
            ellipse(centerX: x, centerY: y, width: width, height: width)
            fillColor(red: 1, green: 1, blue: 1, alpha: 1)
            ellipse(centerX: x, centerY: y, width: width * 0.67, height: width * 0.67)
            fillColor(red: 1, green: 0, blue: 0, alpha: 1)
            ellipse(centerX: x, centerY: y, width: width * 0.33, height: width * 0.33)
            
            // move the position to prepare for next iteration
            x = x + spacing
        }
    }
    
}

