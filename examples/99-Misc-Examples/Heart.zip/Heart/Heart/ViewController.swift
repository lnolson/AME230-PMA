//
//  ViewController.swift
//
//  Heart
//  This project is based on p5js sketch by Daniel Shiffman.
//  https://editor.p5js.org/codingtrain/sketches/C0kJ-BjYW
//
//  Via Twitter, Shiffman credits this MathWorld webpage for the math.
//  http://mathworld.wolfram.com/HeartCurve.html



import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Heart"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.1)
        
        // This value is used to control the animation.
        // It will produce a number that starts at 0, and over
        // four seconds it ascends to 0.5
        let finish = Double( tin.frameCount % 240 ) / 480.0
        
        // Move the heart drawing to the center of the view.
        translate(dx: tin.midX, dy: tin.midY)
        
        lineWidth(4.0)
        strokeColor(gray: 1.0)
        fillColor(red: 1.0, green: 0.1, blue: 0.1, alpha: 1.0)
        pathBegin()
        
        var percent = 0.0
        while percent <= finish {
            
            // a is a value from 0 to 2pi
            let a = remap(value: percent, start1: 0.0, stop1: 0.5, start2: 0.0, stop2: Double.pi * 2.0)
            
            // calculate the point on the curve at parameter value a.
            let x = (16.0 * pow(sin(a), 3.0)) * 10.0
            let y = (13.0 * cos(a) - 5.0 * cos(2 * a) - 2.0 * cos(3.0 * a) - cos(4.0 * a)) * 10.0
            
            pathVertex(x: x, y: y)
            
            percent += 0.002
        }
        
        pathEnd()

        if finish >= 0.49 {
            // When the heart is completed, stop updates. (no more re-drawing)
            view?.stopUpdates()
        }
        else {
            // Draw the small circle on top that is at the leading
            // point of the drawing progress.
            let a = remap(value: finish, start1: 0.0, stop1: 0.5, start2: 0.0, stop2: Double.pi * 2.0)
            let x = (16.0 * pow(sin(a), 3.0)) * 10.0
            let y = (13.0 * cos(a) - 5.0 * cos(2 * a) - 2.0 * cos(3.0 * a) - cos(4.0 * a)) * 10.0
            fillColor(red: 1, green: 1, blue: 1, alpha: 1)
            ellipse(centerX: x, centerY: y, width: 5, height: 5)
        }
        
    }
    
}

