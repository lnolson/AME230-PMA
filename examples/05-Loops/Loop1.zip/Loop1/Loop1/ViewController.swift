//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Drawing"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    
    override func update() {
        
        background(gray: 0.5)
        strokeDisable()
        
        // Loop demo
        // This while loop will draw the target shape 8 times.
        
        var count = 0
        var x = 50.0
        let y = 200.0
        let width = 80.0
        while count < 8 {
            
            fillColor(red: 0.8, green: 0.1, blue: 0.1, alpha: 1.0)
            ellipse(centerX: x, centerY: y, width: width, height: width)
            
            let w1 = width * 0.667
            fillColor(red: 1, green: 1, blue: 1, alpha: 1)
            ellipse(centerX: x, centerY: y, width: w1, height: w1)
            
            let w2 = width * 0.333
            fillColor(red: 0.8, green: 0.1, blue: 0.1, alpha: 1.0)
            ellipse(centerX: x, centerY: y, width: w2, height: w2)
            
            x = x + 100.0
            count = count + 1
        }
        //
        
        
        view?.stopUpdates()
    }
    
}

