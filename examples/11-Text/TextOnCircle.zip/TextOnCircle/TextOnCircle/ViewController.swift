//
//  ViewController.swift

//  Draw text on a circle.
//  The text is drawn one character at a time.

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Text On Circle"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
        scene.updateOffset(dx: tin.mouseX - tin.pmouseX)
    }

}


class Scene: TScene {
    
    var msgFont = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 50.0)
    var message = "Arizona State University"
    var offset = 0.0
    
    
    override func update() {
        background(gray: 0.5)
        
        // Draw two centered lines as reference.
        lineWidth(1.0)
        fillDisable()
        strokeColor(gray: 0)
        line(x1: 0, y1: tin.midY, x2: tin.width, y2: tin.midY)
        line(x1: tin.midX, y1: 0, x2: tin.midX, y2: tin.height)
        
        // Draw the reference circle
        let radius = 250.0
        ellipse(centerX: tin.midX, centerY: tin.midY, width: radius * 2, height: radius * 2)
        
        fillColor(gray: 1)
        msgFont.horizontalAlignment = .center
        
        // Calculate the size of the text using this font.
        let messageSize = msgFont.size(ofMessage: message)
        let messageLength = Double(messageSize.width)
        
        pushState()
        translate(dx: tin.midX, dy: tin.midY)
        
        // The letters need a 90 degree rotation to position correct.
        // The reason is that the zero rotation point is along the X axis,
        // but the letters "up" direction is up the Y axis.
        let orient = -(.pi / 2.0)
        
        // centerOffset is a calculation of how much to rotate the text
        // so that it ends up centered on the top of the circle.
        let centerOffset = -1.0 * .pi - (.pi - (messageLength / radius)) / 2.0
        
        var arcLength = 0.0
        
        for c in message {
            let letterSize = msgFont.size(ofMessage: "\(c)")
            let halfWidth = Double(letterSize.width) / 2.0

            arcLength -= halfWidth
            
            // theta is how far this letter should be rotated around the circle.
            // The offset variable allows us to drag the mouse, and move the
            // text around the circle.
            let theta = (arcLength / radius) + centerOffset + offset
            
            pushState()
            
            // Translate the letter out to the edge of the circle.
            let dx = radius * cos(theta)
            let dy = radius * sin(theta)
            translate(dx: dx, dy: dy)
            
            // Rotate the letter around the circle.
            rotate(by: theta)
            
            // Pivot the letter so that up is along the X axis
            rotate(by: orient)
            
            text(message: "\(c)", font: msgFont, x: 0 , y: 0)
    
            popState()

            arcLength -= halfWidth
        }
        
        popState()

    }
    
    
    
    func updateOffset(dx: Double) {
        offset += dx * 0.01
    }
    
}

