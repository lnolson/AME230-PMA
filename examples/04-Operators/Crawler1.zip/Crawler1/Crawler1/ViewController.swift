//
//  ViewController.swift
//  Crawler 1
//
//

import Cocoa
import Tin


class ViewController: TController {

    //
    // viewWillAppear will be called once, just before the view is placed on screen.
    //
    override func viewWillAppear() {
        view.window?.title = "Crawler 1"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    // ****** PLEASE NOTE ******
    // Variables that are declared here, inside the Scene class block,
    // but outside of the update function, will remember their values
    // for the entire run of the program.
    
    // position and size of the crawler.
    var x = 0.0
    var y = 0.0
    var w = 60.0
    var h = 40.0
    
    // state == 0 moving up
    // state == 1 moving right
    // state == 2 moving down
    // state == 3 moving left
    var state = 0
    
    var speed = 4.0
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        if state == 0 {
            y = y + speed
            if y + h >= tin.height {
                // hit the top edge
                state = 1
                y = tin.height - h
            }
        }
        else if state == 1 {
            x = x + speed
            if x + w > tin.width {
                // hit the right edge
                state = 2
                x = tin.width - w
            }
        }
        else if state == 2 {
            y = y - speed
            if y <= 0 {
                // hit the bottom edge
                state = 3
                y = 0
            }
        }
        else {
            x = x - speed
            if x <= 0.0 {
                // hit the left edge
                state = 0
                x = 0
            }
        }
        
        // Draw the crawler object
        strokeColor(gray: 0.0)
        fillColor(gray: 0.9)
        rect(x: x, y: y, width: w, height: h)
        
    } // End of the update function.
    
} // End of the Scene class.


