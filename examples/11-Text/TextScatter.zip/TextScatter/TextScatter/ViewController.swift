//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Text Scatter"
        makeView(width: 1200.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    override func keyDown(with event: NSEvent) {
        scene.toggle()
    }

}


class Scene: TScene {
    
    var font1 = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 60.0)
    var letters: [Letter] = []
    var message = "Herberger Institute for Design and the Arts"
    var time = 1.0
    var inc = -1.0 / 120.0
    var isAnimating = false
    
    override func setup() {
        //
        // Create a Letter object for each character in the message String.
        // Letter objects are stored in the letters aray.
        
        let messageSize = font1.size(ofMessage: message)
        let messageWidth = Double(messageSize.width)
        var x = tin.midX - (messageWidth / 2.0)
        let y = tin.midY
        
        for c in message {
            let letterSize = font1.size(ofMessage: "\(c)")
            let letterWidth = Double(letterSize.width)
            let xc = (letterWidth / 2.0) + x
            
            let letter = Letter(letter: "\(c)", x: xc, y: y, font: font1)
            letters.append(letter)
            
            x += letterWidth
        }
    }
    
    
    override func update() {
        background(gray: 0.5)
        
        lineWidth(1.0)
        strokeColor(gray: 0.4)
        line(x1: 0, y1: tin.midY, x2: tin.width, y2: tin.midY)
        line(x1: tin.midX, y1: 0, x2: tin.midX, y2: tin.height)
        
        if isAnimating {
            time += inc
            if time <= 0.0 {
                time = 0.0
                inc = 1.0 / 120.0
                isAnimating = false
            }
            else if time >= 1.0 {
                time = 1.0
                inc = -1.0 / 120.0
                isAnimating = false
            }
        }
        
        fillColor(gray: 1)
        for letter in letters {
            letter.render(t: time)
        }
    }
    
    
    
    func toggle() {
        isAnimating = !isAnimating
    }
    
}

