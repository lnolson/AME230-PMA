//
//  ViewController.swift
//  
//

import Cocoa
import Tin

class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        
        view.window?.title = "Cart Demo"
        makeView(width: 1200.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    

    // Click and drag mouse left-right to move the cart.
    override func mouseDragged(with event: NSEvent) {
        super.mouseDragged(with: event)
        let mouseDx = tin.mouseX - tin.pmouseX
        scene.moveCart(dx: mouseDx)
    }

}


class Scene: TScene {
    // scene properties here
    var cart = Cart()
    
    
    override func update() {
        background(red: 0.3548, green: 0.4722, blue: 0.9451)
        
        // Ground
        fillColor(red: 0.05, green: 0.4, blue: 0.1, alpha: 1)
        strokeDisable()
        rect(x: 0, y: 0, width: tin.width, height: 160.0)
        
        cart.render()
    }
    
    
    func moveCart(dx: Double) {
        cart.move(dx: dx)
    }
    
}

