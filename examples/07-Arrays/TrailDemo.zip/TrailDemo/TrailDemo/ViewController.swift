//
//  ViewController.swift
//
//  A mouse trail that demos use of arrays.


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Mouse Trail"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    // two arrays to store the position of the mouse pointer.
    var xList: [Double] = []
    var yList: [Double] = []
    
    override func update() {
        background(gray: 0.5)
        
        let mx = tin.mouseX
        let my = tin.mouseY
        
        // remember the current mouse position
        xList.append(mx)
        yList.append(my)
        
        strokeDisable()
        
        let circleSize = 40.0
        var alpha = 0.0
        let delta = 1.0 / Double(xList.count)
        var i = 0
        while i < xList.count {
            // draw
            
            let x = xList[i]
            let y = yList[i]
            
            fillColor(red: 0.95, green: 0.95, blue: 0.95, alpha: alpha)
            ellipse(centerX: x, centerY: y, width: circleSize * alpha, height: circleSize * alpha)
            
            i = i + 1
            alpha = alpha + delta
        }
        
        // If there are more than 100 values saved, then
        // remove the oldest. (value at index 0)
        if xList.count > 100 {
            xList.remove(at: 0)
            yList.remove(at: 0)
        }
        
        
    }
    
}

