//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Drawing"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    var a = 0.0
    
    override func update() {
        
        background(gray: 0.5)
        
        
        line(x1: 100, y1: 100, x2: 700, y2: 100)
        line(x1: 100, y1: 300, x2: 700, y2: 300)
        line(x1: 100, y1: 500, x2: 700, y2: 500)
        
        line(x1: 100, y1: 100, x2: 100, y2: 500)
        line(x1: 400, y1: 100, x2: 400, y2: 500)
        line(x1: 700, y1: 100, x2: 700, y2: 500)
        
        pushState()
        translate(dx: 300, dy: 300)
        rotate(by: a)
        fillColor(red: 1, green: 0, blue: 0, alpha: 1)
        rect(x: -50, y: -50, width: 100, height: 100)
        popState()
        
        a = a + 0.04
        
        pushState()
        translate(dx: 500, dy: 300)
        rotate(by: -a)
        fillColor(red: 0, green: 1, blue: 0, alpha: 1)
        rect(x: -50.0, y: -50, width: 100, height: 100)
        popState()
        
    }
    
}

