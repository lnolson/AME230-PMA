//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {
    var scene: Scene!
    
    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }
    
    
    // This method is called when the user releases a key on the keyboard.
    override func keyUp(with event: NSEvent) {
        if event.characters == "s" {
            // When the user presses "s", call the startAnimation method.
            scene.startAnimation()
        }
    }

} // end of ViewController class


class Scene: TScene {
    
    var font1 = TFont(fontName: "Futura Condensed ExtraBold", ofSize: 120.0)
    var message1 = "Arizona"
    var message2 = "State"
    
    // variables used to position Word 1
    var x1 = 400.0
    var y1 = 620.0
    let startY1 = 620.0
    let endY1 = 300.0
    
    // variables used to position Word 2
    var x2 = 400.0
    var y2 = -300.0
    let startY2 = -300.0
    let endY2 = 190.0
    
    // variables used to control the animation
    // When isAnimationRunning is true, the animation is in progress.
    var isAnimationRunning = false
    var stepper1 = AnimationStepper(length: 60)
    var stepper2 = AnimationStepper(length: 60)
    
    
    override func update() {
        background(gray: 0.5)
        
        // These 3 lines were only for reference
        // to help understand position of text.
        //strokeColor(gray: 0.3)
        //line(x1: 0, y1: tin.midY, x2: tin.width, y2: tin.midY)
        //line(x1: tin.midX, y1: 0, x2: tin.midX, y2: tin.height)
        
        if isAnimationRunning {
            animationStep()
        }
            
        text(message: message1, font: font1, x: x1, y: y1)
        
        text(message: message2, font: font1, x: x2, y: y2)
    }
    
    func startAnimation() {
        print("please start now.")
        
        y1 = startY1
        y2 = startY2
        isAnimationRunning = true
        stepper1.reset()
        stepper2.reset()
    }
    
    func animationStep() {
        
        stepper1.step()
        
        // Stepper2 doesn't get called for the first 15 frames while
        // stepper1 is running. The effect is that stepper2 is 15 frames
        // delayed.
        if stepper1.count >= 15 {
            if stepper2.step() == false {
                // When stepper2 is finsihed, the entire animation is finished.
                isAnimationRunning = false
            }
        }
        
        // Get the current time value (a number 0-1) for each stepper.
        
        let t1 = stepper1.time()
        let t2 = stepper2.time()
        
        // Calculate the current values, given the animation timing.
        
        y1 = smoothstep(startValue: startY1, endValue: endY1, t: t1)
        y2 = smoothstep(startValue: startY2, endValue: endY2, t: t2)
        
    }
    
}

