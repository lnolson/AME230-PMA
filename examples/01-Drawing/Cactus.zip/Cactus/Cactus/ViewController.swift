//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Drawing"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(red: 0.3376, green: 0.5612, blue: 0.7618)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        strokeDisable()
        
        fillColor(red: 0.5986, green: 0.5372, blue: 0.4388, alpha: 1.0)
        rect(x: 0, y: 0, width: tin.width, height: 200)
        
        fillColor(red: 0.5375, green: 0.8314, blue: 0.4601, alpha: 1.0)
        // trunk
        rect(x: 300, y: 100, width: 100, height: 300)
        ellipse(centerX: 350, centerY: 400, width: 100, height: 100)
        
        // left arm
        rect(x: 250, y: 250, width: 50, height: 60)
        ellipse(centerX: 250, centerY: 280, width: 60, height: 60)
        rect(x: 220, y: 280, width: 60, height: 60)
        ellipse(centerX: 250, centerY: 340, width: 60, height: 60)
        
        // right arm
        rect(x: 400, y: 180, width: 50, height: 60)
        ellipse(centerX: 450, centerY: 210, width: 60, height: 60)
        rect(x: 420, y: 210, width: 60, height: 130)
        ellipse(centerX: 450, centerY: 340, width: 60, height: 60)
        
        
        
        // Your drawing code should be above this comment.
        // *************************************************
        
        view?.stopUpdates()
    }
    
}

