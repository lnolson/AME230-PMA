//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Image"
        makeView(width: 1000.0, height: 600.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var bird: TImage!
    
    
    override func setup() {
        // The image must be added to the Xcode project.
        // The image also needs to be part of the "target membership"
        // of this application. Select the image, and look at the
        // File inspector to verify the membership.
        bird = TImage(contentsOfFileInBundle: "puffin_medium.jpg")
    }
    
    
    override func update() {
        background(gray: 0.5)
        
        // Draw the image centered in the view.
        // x,y is the bottom, left corner of the image.
        let x = tin.midX - (bird.width / 2.0)
        let y = tin.midY - (bird.height / 2.0)
        bird.draw(x: x, y: y)

    }
}

