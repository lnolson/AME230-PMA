//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Bounce"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    // Variables that are declared here, inside the Scene class block,
    // but outside of the update function, will remember their values
    // for the entire run of the program.
    var positionX = 400.0
    var positionY = 300.0
    var radius = 30.0
    var velocityX = 4.5
    var velocityY = -1.5
    
    
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        background(gray: 0.5)
        
        // *****************************************************************
        // Move the ball (eg. change the value of positionX, positionY)
        
        positionX = positionX + velocityX
        positionY = positionY + velocityY
        
        let rightEdge = tin.width
        let leftEdge = 0.0
        let topEdge = tin.height
        let bottomEdge = 0.0
        
        if positionX + radius > rightEdge {
            // ran off the right edge
            positionX = rightEdge - radius
            velocityX = velocityX * -1.0
        }
        else if positionX - radius < leftEdge {
            // ran off the left edge
            positionX = leftEdge + radius
            velocityX = velocityX * -1.0
        }
        
        if positionY + radius > topEdge {
            // ran off the top edge
            positionY = topEdge - radius
            velocityY = velocityY * -1.0
        }
        else if positionY - radius < bottomEdge {
            // ran off the bottom edge
            positionY = bottomEdge + radius
            velocityY = velocityY * -1.0
        }
        
        
 
        // *****************************************************************
        // Draw the ball
        
        strokeColor(gray: 0)
        fillColor(gray: 1.0)
        ellipse(centerX: positionX, centerY: positionY, width: radius * 2, height: radius * 2)
        
    } // End of the update function.
    
    
} // End of the Scene class.

