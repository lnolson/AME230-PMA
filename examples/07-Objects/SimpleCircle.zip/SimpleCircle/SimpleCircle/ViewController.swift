//
//  ViewController.swift
//

import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        super.viewWillAppear()

        view.window?.title = "Simple Circle"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    var myCircle = Circle(x: 400, y: 300, radius: 50)
    
    
    override func setup() {
        // The setup() function is used for initializing properties and performing
        // computations that only need to happen once.
        
    }
    
    
    override func update() {
        // The update() function is used to redraw the view.
        // Add your drawing code here, inside this function.
        
        background(gray: 0.5)
        
        myCircle.render()
        
    }
    
}

