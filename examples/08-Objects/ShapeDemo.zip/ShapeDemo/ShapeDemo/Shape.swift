//
//  Shape.swift
//  ShapeDemo
//
//  Created by Loren Olson on 2/26/19.
//  Copyright © 2019 ASU. All rights reserved.
//

import Foundation
import Tin


enum ShapeStyle {
    case ellipse
    case rectangle
    case star
}

class Shape {
    var x: Double
    var y: Double
    var radius: Double
    var colorR: Double
    var colorG: Double
    var colorB: Double
    var colorA: Double
    var style: ShapeStyle
    var numberOfPoints: Int
    var armDepth: Double
    var angle: Double
    
    init(x: Double, y: Double, radius: Double, style: ShapeStyle) {
        self.x = x
        self.y = y
        self.radius = radius
        self.style = style
        colorR = 1.0
        colorG = 1.0
        colorB = 1.0
        colorA = 1.0
        numberOfPoints = 9
        armDepth = 0.5
        angle = 0.0
    }
    
    func render() {
        fillColor(red: colorR, green: colorG, blue: colorB, alpha: colorA)
        if style == .ellipse {
            ellipse(centerX: x, centerY: y, width: radius * 2.0, height: radius * 2)
        }
        else if style == .rectangle {
            rect(x: x - radius, y: y - radius, width: radius * 2.0, height: radius * 2)
        }
        else if style == .star {
            renderStar()
        }
    }
    
    func renderStar() {
        pathBegin()
        
        let offset = (.pi * 2.0) / Double(numberOfPoints * 2)
        
        var a = angle
        for _ in 0 ..< numberOfPoints {
            let x1 = radius * cos( a ) + x
            let y1 = radius * sin( a ) + y
            pathVertex(x: x1, y: y1)
            
            a += offset
            
            let x2 = radius * armDepth * cos( a ) + x
            let y2 = radius * armDepth * sin( a ) + y
            pathVertex(x: x2, y: y2)
            
            a += offset
        }
        pathClose()
    }
}

