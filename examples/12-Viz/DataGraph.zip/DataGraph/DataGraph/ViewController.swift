//
//  ViewController.swift

//

import Cocoa
import Tin


class ViewController: TController {

    var scene: Scene!
    
    override func viewWillAppear() {
        super.viewWillAppear()
        view.window?.title = "Weather Data"
        makeView(width: 1400.0, height: 800.0)
        scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


enum WeatherDataType {
    case actual_max_temp
    case actual_min_temp
    case average_max_temp
}


class Scene: TScene {
    var headerFont = TFont(fontName: "Helvetica Neue Condensed Black", ofSize: 36.0)
    var font1 = TFont(fontName: "Futura Condensed ExtraBold", ofSize: 16.0)
    var numbersFont = TFont(fontName: "Courier New", ofSize: 16.0)
    var daysFont = TFont(fontName: "Courier New", ofSize: 12.0)
    var weather = WeatherData(contentsOfFile: "KPHX.csv")
    let margins = 150.0
    var graphX = 0.0
    var graphY = 0.0
    var graphWidth = 0.0
    var graphHeight = 0.0
    var graphX2 = 0.0
    var graphY2 = 0.0
    
    override func setup() {
        
        font1.horizontalAlignment = .left
        graphX = margins
        graphY = margins
        graphWidth = tin.width - (margins * 2.0)
        graphHeight = tin.height - (margins * 2.0)
        graphX2 = graphX + graphWidth
        graphY2 = graphY + graphHeight
    }
    
    
    override func update() {
        background(gray: 0.9)
        
        
        
        fillColor(gray: 0.85)
        strokeColor(gray: 0.0)
        rect(x: graphX, y: graphY, width: graphWidth, height: graphHeight)
        
        xValueLabels()
        yValueLabels()
        
        fillDisable()
        strokeColor(red: 0.9, green: 0, blue: 0, alpha: 1)
        drawLine(valueType: .actual_max_temp)
        
        
        strokeColor(red: 0.0, green: 0.75, blue: 0, alpha: 1)
        drawLine(valueType: .average_max_temp)
        
        fillDisable()
        strokeColor(red: 0.0, green: 0, blue: 0.9, alpha: 1)
        drawLine(valueType: .actual_min_temp)
        
        
        drawTitle()

        
        view?.stopUpdates()
    }
    
    
    func drawLine(valueType: WeatherDataType) {
        var px = 0.0
        var py = 0.0
        var index = 0
        
        lineWidth(1)
        
        for point in weather.data {
            let x = remap(value: Double(index), start1: 0, stop1: 364, start2: graphX + 5.0, stop2: graphX2 - 5.0)
            let y: Double
            
            switch valueType {
            case .actual_max_temp:
                y = remap(value: Double(point.actual_max_temp), start1: 10.0, stop1: 130.0, start2: graphY, stop2: graphY2)
            case .actual_min_temp:
                y = remap(value: Double(point.actual_min_temp), start1: 10.0, stop1: 130.0, start2: graphY, stop2: graphY2)
            case .average_max_temp:
                y = remap(value: Double(point.average_max_temp), start1: 10.0, stop1: 130.0, start2: graphY, stop2: graphY2)
            }
            
            if index > 0 {
                line(x1: px, y1: py, x2: x, y2: y)
            }
            
            ellipse(centerX: x, centerY: y, width: 5.0, height: 5.0)
            
            px = x
            py = y
            index += 1
        }
    }
    
    
    func yValueLabels() {
        lineWidth(1)
        numbersFont.horizontalAlignment = .right
        numbersFont.verticalAlignment = .center
        for vy in stride(from: 20, to: 130, by: 10) {
            
            strokeColor(gray: 0.75)
            let y = remap(value: Double(vy), start1: 10.0, stop1: 130.0, start2: graphY, stop2: graphY2)
            line(x1: graphX, y1: y, x2: graphX2, y2: y)
            
            fillColor(gray: 0.01)
            strokeDisable()
            text(message: "\(vy)", font: numbersFont, x: graphX - 5.0, y: y)
            
        }
        
    }
    
    
    func xValueLabels() {
        lineWidth(1)
        daysFont.horizontalAlignment = .center
        daysFont.verticalAlignment = .top
        // every 30 days? This isn't very good.
        for vx in stride(from: 0, to: 364, by: 30) {
            
            strokeColor(gray: 0.75)
            let x = remap(value: Double(vx), start1: 0, stop1: 364, start2: graphX + 5.0, stop2: graphX2 - 5.0)
            line(x1: x, y1: graphY, x2: x, y2: graphY2)
            
            fillColor(gray: 0.01)
            strokeDisable()
            
            let day = weather.data[vx]
            text(message: "\(day.date)", font: daysFont, x: x, y: graphY - 5.0)
            
        }
        
    }
    
    
    func drawTitle() {
        // Header
        fillColor(gray: 0.01)
        headerFont.horizontalAlignment = .center
        text(message: "Phoenix Temperatures", font: headerFont, x: tin.midX, y: tin.height - 80.0)
    }
    

}

