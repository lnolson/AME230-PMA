//
//  ViewController.swift
//  Drawing
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Mouse Position"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        //
        // let circleX = constrain(value: tin.mouseX, min: 100.0, max: 700.0)
        
        // turn mouseX into a value between 0-1
        let red = tin.mouseX / tin.width
        
        // turn mouseY into a value between 0-1
        let green = tin.mouseY / tin.height
        
        // fill color using mouse position as input
        fillColor(red: red, green: green, blue: 1.0, alpha: 1.0)
        
        // draw a circle at mouse position
        ellipse(centerX: tin.mouseX, centerY: tin.mouseY, width: 150, height: 150)
        
        
        // Your drawing code should be above this comment.
        // *************************************************
        
    }
    
}

