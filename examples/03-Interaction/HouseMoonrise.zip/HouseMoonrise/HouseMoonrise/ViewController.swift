//
//  ViewController.swift
//  HouseMoonrise
//
//  A simple drawing created during class discussion.
//  Now using variables.
//
//  Move the moon with vertical movement of the mouse.


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Moonrise"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    //
    // The update function is called to draw the view automatically.
    //
    override func update() {
        // background erases the view and sets the entire view to one flat
        // color. If you want a different background color, change it here.
        background(gray: 0.5)
        
        // *************************************************
        // Insert your drawing code here, below this comment
        
        // sky
        strokeDisable()
        fillColor(red: 0.1, green: 0.2, blue: 0.4, alpha: 1.0)
        rect(x: 0.0, y: 0.0, width: 800.0, height: 600.0)
        
        // moon
        
        let moonPositionX = 650.0
        let moonWidth = 80.0
        
        // I want the moon to be just above the top of the view when the mouseY
        // is at the top of the view, and I want the moon to be just below the
        // horizon when the mouseY is at the bottom of the view.
    
        // topRange is position of the moon at the top (out of view)
        let topRange = tin.height + moonWidth / 2.0
        // bottomRange is the position of the moon at the bottom (below horizon)
        let bottomRange = tin.midY - moonWidth / 2.0
        // ratio is the relative Y position of mouse in view. (a value between 0 - 1)
        let ratio = tin.mouseY / tin.height
        
        let moonPositionY = bottomRange + ratio * (topRange - bottomRange)
        
        strokeDisable()
        fillColor(gray: 0.85)
        ellipse(centerX: moonPositionX, centerY: moonPositionY, width: moonWidth, height: moonWidth)
        fillColor(red: 0.1, green: 0.2, blue: 0.4, alpha:1.0)
        ellipse(centerX: moonPositionX + 20, centerY: moonPositionY, width: moonWidth - 10, height: moonWidth - 10)
        
        // ground
        let horizonPosition = tin.midY
        fillColor(red: 0.1, green: 0.4, blue: 0.15, alpha: 1.0)
        rect(x: 0.0, y: 0.0, width: 800.0, height: horizonPosition)
        
        // house
        
        let housePositionX = 300.0
        let housePositionY = 200.0
        let houseBaseWidth = 200.0
        let houseBaseHeight = 200.0
        let peakHeight = 100.0
        fillColor(gray: 0.85)
        rect(x: housePositionX, y: housePositionY, width: houseBaseWidth, height: houseBaseHeight)
        // peak
        triangle(x1: housePositionX, y1: housePositionY + houseBaseHeight,
                 x2: housePositionX + houseBaseWidth, y2: housePositionY + houseBaseHeight,
                 x3: housePositionX + houseBaseWidth / 2.0, y3: housePositionY + houseBaseHeight + peakHeight)
        // roof
        strokeColor(gray: 0.5)
        lineWidth(9.0)
        pathBegin()
        pathVertex(x: housePositionX, y: housePositionY + houseBaseHeight)
        pathVertex(x: housePositionX + houseBaseWidth / 2.0, y: housePositionY + houseBaseHeight + peakHeight)
        pathVertex(x: housePositionX + houseBaseWidth, y: housePositionY + houseBaseHeight)
        pathEnd()
        
        // door
        
        let doorPositionX = housePositionX + 20.0
        let doorPositionY = housePositionY
        strokeColor(gray: 0.0)
        lineWidth(2.0)
        fillColor(gray: 0.8)
        rect(x: doorPositionX, y: doorPositionY, width: 60.0, height: 150.0)
        
        // window
        let windowPositionX = housePositionX + 110.0
        let windowPositionY = housePositionY + 40.0
        let windowWidth = 60.0
        let windowHeight = 90.0
        fillColor(gray: 0.75)
        rect(x: windowPositionX, y: windowPositionY, width: windowWidth, height: windowHeight)
        lineWidth(4.0)
        strokeColor(gray: 0.2)
        let windowMidY = windowPositionY + windowHeight / 2.0
        let windowMidX = windowPositionX + windowWidth / 2.0
        line(x1: windowPositionX, y1: windowMidY, x2: windowPositionX + windowWidth, y2: windowMidY)
        line(x1: windowMidX, y1: windowPositionY, x2: windowMidX, y2: windowPositionY + windowHeight)
        
        
        
        // Your drawing code should be above this comment.
        // *************************************************
        
        
    }
    
}

