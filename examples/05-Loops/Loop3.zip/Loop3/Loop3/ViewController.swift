//
//  ViewController.swift
//


import Cocoa
import Tin


class ViewController: TController {

    override func viewWillAppear() {
        view.window?.title = "Project"
        makeView(width: 800.0, height: 600.0)
        let scene = Scene()
        present(scene: scene)
        scene.view?.showStats = false
    }

}


class Scene: TScene {
    
    
    override func update() {
        background(gray: 0.5)
        
        // Draw 1000 random circles.
        var count = 0
        while count < 1000 {
            
            // These random numbers are used to position and size the circle.
            // A random value for x that is in the range 0 -> view width.
            let x = random(max: tin.width)
            // A random value for y that is in the range 0 -> view height.
            let y = random(max: tin.height)
            // A random value for width that is in the range 10.0 -> 200.0
            let width = random(min: 10.0, max: 200.0)
            
            strokeDisable()
            // A random color, that is 25% transparent.
            fillColor(red: random(max: 1), green: random(max: 1), blue: random(max: 1), alpha: 0.25)
            
            ellipse(centerX: x, centerY: y, width: width, height: width)
            
            count = count + 1
        }
        
        view?.stopUpdates()
    }
    
}

